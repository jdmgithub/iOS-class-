Saving Images Tutorial
=============================

This Xcode project teaches you how to take a photo and upload it directly to Parse.

How to Run
----------

1. Clone the repository and open the Xcode project.
2. Add your Parse application id and client key in `AppDelegate.m`

Helper Classes
----------

[MBProgressHUD](https://github.com/jdg/MBProgressHUD)

Learn More
----------

To learn more, take a look at the [Saving Images](https://parse.com/tutorials/saving-images) tutorial.

