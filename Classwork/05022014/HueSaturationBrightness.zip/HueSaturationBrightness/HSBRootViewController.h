//
//  HSBRootViewController.h
//  HueSaturationBrightness
//
//  Created by Jisha Obukwelu on 5/2/14.
//  Copyright (c) 2014 Jisha Obukwelu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HSBRootViewController : UIViewController

@end
