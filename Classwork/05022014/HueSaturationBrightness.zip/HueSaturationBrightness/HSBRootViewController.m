//
//  HSBRootViewController.m
//  HueSaturationBrightness
//
//  Created by Jisha Obukwelu on 5/2/14.
//  Copyright (c) 2014 Jisha Obukwelu. All rights reserved.
//

#import "HSBRootViewController.h"
#import "HSBColorControlVC.h"

@interface HSBRootViewController () <HSBColorControlVCDelegate>

@end

@implementation HSBRootViewController
{
    HSBColorControlVC * colorControlVC;
    UIScrollView * scrollView;
    UIImageView * imageView;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
        imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 10, SCREEN_WIDTH,SCREEN_HEIGHT - 100)];
        imageView.image = [UIImage imageNamed:@"boss"];
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        [self.view addSubview:imageView];
        
        scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT - 100, SCREEN_WIDTH, 100)];
        scrollView.backgroundColor = [UIColor orangeColor];
        [self.view addSubview:scrollView];
        
        UIButton * hsbButton = [[UIButton alloc]initWithFrame:CGRectMake(10, 10, 50, 50)];
        hsbButton.backgroundColor = [UIColor yellowColor];
        [hsbButton addTarget:self action:@selector(goToColorVC) forControlEvents:UIControlEventTouchUpInside];
        [scrollView addSubview:hsbButton];
        
    }
    return self;
}

- (void)goToColorVC
{
    colorControlVC = [[HSBColorControlVC alloc] initWithNibName:nil bundle:nil];
    colorControlVC.currentImage = imageView.image;
    colorControlVC.delegate = self;
    [scrollView addSubview: colorControlVC.view];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)updateCurrentImageWithHSB: (UIImage * )image
{
    imageView.image = image;
    NSLog(@"hello image");
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
