//
//  HSBAppDelegate.m
//  HueSaturationBrightness
//
//  Created by Jisha Obukwelu on 5/2/14.
//  Copyright (c) 2014 Jisha Obukwelu. All rights reserved.
//

#import "HSBAppDelegate.h"
#import "HSBRootViewController.h"

@implementation HSBAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    self.window.rootViewController = [[HSBRootViewController alloc] initWithNibName:nil bundle:nil];
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}


@end
