//
//  MGALogin.m
//  MusicGrid
//
//  Created by Jisha Obukwelu on 6/7/14.
//  Copyright (c) 2014 Jisha Obukwelu. All rights reserved.
//

#import "MGALogin.h"
#import <Parse/Parse.h>
#import "MGASwipeView.h"
#import "MGASignUp.h"
#import "MGANav.h"

@interface MGALogin () <UITextFieldDelegate>

@end

@implementation MGALogin
{
    UIView * logInPage;
    UITextField * loginField;
    UITextField * passwordField;
    UIButton * signIn;
    UIButton * signUp;
    
    float logInOrigY;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        logInOrigY = (self.view.frame.size.height - 200)/2;
        
        logInPage = [[UIView alloc] initWithFrame:CGRectMake(20, logInOrigY, 280, 200)];
        [self.view addSubview:logInPage];
        
        loginField = [[UITextField alloc] initWithFrame:CGRectMake(0, 0, 280, 40)];
        loginField.backgroundColor = [UIColor lightGrayColor];
        loginField.alpha = 0.7;
        loginField.placeholder = @"USERNAME";
        loginField.textAlignment = NSTextAlignmentCenter;
        loginField.layer.cornerRadius = 6;
        loginField.font = [UIFont fontWithName:@"HELVETICA" size:15];
        loginField.autocorrectionType = UITextAutocapitalizationTypeNone;
        loginField.autocapitalizationType = FALSE;
        [logInPage addSubview:loginField];
        
        loginField.delegate = self;
        
        passwordField = [[UITextField alloc] initWithFrame:CGRectMake(0, 50, 280, 40)];
        passwordField.backgroundColor = [UIColor lightGrayColor];
        passwordField.alpha = 0.7;
        passwordField.textAlignment = NSTextAlignmentCenter;
        passwordField.layer.cornerRadius = 6;
        passwordField.placeholder = @"PASSWORD";
        passwordField.textAlignment = NSTextAlignmentCenter;
        passwordField.font = [UIFont fontWithName:@"HELVETICA" size:15];
        passwordField.secureTextEntry = YES;
        [logInPage addSubview:passwordField];
        
        passwordField.delegate = self;
        
        signIn = [[UIButton alloc] initWithFrame:CGRectMake(0, 100, 280, 40)];
        [signIn setTitle:@"SIGN IN" forState:UIControlStateNormal];
        signIn.titleLabel.textColor = [UIColor whiteColor];
        signIn.layer.cornerRadius = 6;
        signIn.backgroundColor = [UIColor orangeColor];
        signIn.alpha = 0.5;
        [signIn addTarget:self action:@selector(logIn:) forControlEvents:UIControlEventTouchUpInside];
        [logInPage addSubview:signIn];
        
        UILabel * or = [[UILabel alloc] initWithFrame:CGRectMake(0, 140, 280, 20)];
        or.text = @"OR";
        or.textColor = [UIColor blackColor];
        or.font = [UIFont fontWithName:@"HELEVETICA" size:15];
        or.textAlignment = NSTextAlignmentCenter;
        [logInPage addSubview:or];
        
        signUp = [[UIButton alloc] initWithFrame:CGRectMake(0, 160, 280, 40)];
        [signUp setTitle:@"SIGN UP" forState:UIControlStateNormal];
        signUp.titleLabel.textColor = [UIColor whiteColor];
        signUp.layer.cornerRadius = 6;
        signUp.backgroundColor = [UIColor orangeColor];;
        signUp.alpha = 0.5;
        [signUp addTarget:self action:@selector(showSignUp) forControlEvents:UIControlEventTouchUpInside];
        [logInPage addSubview:signUp];
        
        
        loginField.keyboardType = UIKeyboardAppearanceDefault;
        passwordField.keyboardType = UIKeyboardAppearanceDefault;
        
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapScreen)];
        [self.view addGestureRecognizer:tap];
    }
    return self;
}

- (void)tapScreen
{
    [loginField resignFirstResponder];
    [passwordField resignFirstResponder];
    [UITextField animateWithDuration:0.2 animations:^{
        logInPage.frame = CGRectMake(20, logInOrigY, 280, 190);
    }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)logIn: (UIButton *)signIn
{
    NSLog(@"Login to Parse");
    
    PFUser * user = [PFUser currentUser];
    
    user.username = loginField.text;
    user.password = passwordField.text;
    
    
    UIActivityIndicatorView * activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    activityIndicator.color = [UIColor orangeColor];
    activityIndicator.frame = CGRectMake(0,150,280, 200);
    
    [logInPage addSubview:activityIndicator];
    
    [activityIndicator startAnimating];
    
    //save user in background
    
    [PFUser logInWithUsernameInBackground:loginField.text password:passwordField.text block:^(PFUser *user, NSError *error)
     {
         NSLog(@"logged in %@", user.username);
         NSLog(@"current user %@", [PFUser currentUser].username);
         
         if(error == nil)
         {
             self.navigationController.navigationBarHidden = NO;
             self.navigationController.viewControllers = @[[[MGASwipeView alloc]
                                                            initWithNibName:nil bundle:nil]];
             
         } else {
             
             passwordField.text = nil;
             
             //error.userInfo[@"error"]
             NSString * errorDescription = error.userInfo[@"error"];
             
             //UIAlertView with message
             UIAlertView * alertView = [[UIAlertView alloc] initWithTitle:@"Login Error" message:errorDescription delegate:self
                                                        cancelButtonTitle:@"Try Again" otherButtonTitles:nil];
             [alertView show];
             
             //activity indicator remove
             [activityIndicator removeFromSuperview];
         }}];
}


- (void)showSignUp
{
    MGASignUp * signUpVC = [[MGASignUp alloc] initWithNibName:nil bundle:nil];
    MGANav * nc = [[MGANav alloc] initWithRootViewController:signUpVC];
    nc.navigationBar.barTintColor = [UIColor orangeColor];;
    nc.navigationBar.translucent = NO;
    [self.navigationController presentViewController:nc animated:YES completion:^{}];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UITextField animateWithDuration:0.2 animations:^{
        logInPage.frame = CGRectMake(20, logInOrigY - 50, 280, 190);
    }];
}



@end
