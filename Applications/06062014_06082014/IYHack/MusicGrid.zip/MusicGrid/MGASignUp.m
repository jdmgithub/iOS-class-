//
//  MGASignUp.m
//  MusicGrid
//
//  Created by Jisha Obukwelu on 6/7/14.
//  Copyright (c) 2014 Jisha Obukwelu. All rights reserved.
//

#import "MGASignUp.h"
#import "MGASwipeView.h"
//#import <Parse/Parse.h>



@interface MGASignUp ()<UITextFieldDelegate>

@end

@implementation MGASignUp
{
    UIView * signUpForm;
    UIImageView * avatar;
    NSArray * fieldNames;
    NSMutableArray * fields;
    
    float signUpOrigY;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        self.view.backgroundColor = [UIColor whiteColor];
        
        UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyboard)];
        [self.view addGestureRecognizer:tap];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    UIBarButtonItem * cancelSignUp = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelSignUp)];
    
    cancelSignUp.tintColor = [UIColor whiteColor];
    self.navigationItem.rightBarButtonItem = cancelSignUp;
    
    signUpOrigY = (self.view.frame.size.height - 320)/2;
    
//    signUpForm = [[UIView alloc] initWithFrame:self.view.frame];
//    signUpForm.backgroundColor = [UIColor purpleColor];
//    [self.view addSubview:signUpForm];
    
    fieldNames = @[
                   @"FIRST_NAME",
                   @"LAST_NAME",
                   @"USER NAME",
                   @"PASSWORD",
                   @"PASSWORD_CONFIRMATION",
                   @"EMAIL"];
    
    fields = [@[]mutableCopy];
    
    for(NSString * name in fieldNames)
    {
        // index will = 0,1,2,3,4,5
        
        NSInteger index = [fieldNames indexOfObject:name];
        
        UITextField * textField = [[UITextField alloc] initWithFrame:CGRectMake(20, (index * 50)+ 70, 280, 40)];
        textField.backgroundColor = [UIColor lightGrayColor];
        textField.alpha = 0.7;
        textField.placeholder = name;
        textField.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 40)];
        textField.leftViewMode = UITextFieldViewModeAlways;
        textField.layer.cornerRadius = 6;
        textField.font = [UIFont fontWithName:@"HELVETICA" size:15];
        textField.autocorrectionType = UITextAutocapitalizationTypeNone;
        textField.autocapitalizationType = FALSE;
        textField.delegate = self;
        
        [fields addObject:textField];
        
        [self.view addSubview:textField];
    }
    ((UITextField *)fields [3]).secureTextEntry = YES;
    ((UITextField *)fields [4]).secureTextEntry = YES;
    
    UIButton * registerButton = [[UIButton alloc] initWithFrame:CGRectMake(20, ([fieldNames count] * 50)+70, 280, 40)];
    [registerButton setTitle:@"REGISTER" forState:UIControlStateNormal];
    registerButton.titleLabel.textColor = [UIColor whiteColor];
    registerButton.layer.cornerRadius = 6;
    registerButton.backgroundColor = [UIColor orangeColor];
    registerButton.alpha = 0.5;
    [registerButton addTarget:self action:@selector(registerNewUser:) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:registerButton];
    NSLog(@"push registerButton%@", registerButton);
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)hideKeyboard
{
    for (UITextField * textFieldItem in fields)
    { [textFieldItem resignFirstResponder];}
    
    [UITextField animateWithDuration:0.2 animations:^{
        self.view.frame = self.view.frame;
    }];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    NSInteger index = [fields indexOfObject:textField];
    NSInteger emptyIndex = [fields count];
    
    for (UITextField * textFieldItem in fields)
    {
        NSInteger fieldIndex = [fields indexOfObject:textField];
        if (emptyIndex == [fields count])
        {
            if ([textFieldItem.text isEqualToString:@""])
            {
                emptyIndex = fieldIndex;
            }
        }
    }
    NSLog(@"textFieldIndex: %d", (int)index);
    NSLog(@"emptyIndex: %d", (int)index);
    
    if(index <= emptyIndex) return YES;
    return NO;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    int extraSlide = 0;
    
    // 416 h for 3.5"
    
    if(self.view.frame.size.height >500)// 504 h for 4"
    {
        extraSlide = 107;
        
    } else {// 416 h for 3.5"
        
        NSInteger index = [fields indexOfObject:textField];
        extraSlide = index + 65;
    }
    
    [UITextField animateWithDuration:0.2 animations:^{
        self.view.frame = CGRectMake(0, 0 - extraSlide, self.view.frame.size.width, self.view.frame.size.height);
    }];
}

- (void)cancelSignUp
{
    [self.navigationController dismissViewControllerAnimated:YES completion:^{}];
}

- (void)registerNewUser: (UIButton*)sender
{
    [self hideKeyboard];
    
    NSString *post = @"user";
//    post = [NSString stringWithFormat:@"key1=%@&key2=%@",
//                      [self urlEncodeValue:val1]
//                      [self urlEncodeValue:val2]];
    NSData *postData = [post dataUsingEncoding:NSASCIIStringEncoding allowLossyConversion:YES];
    
    NSString *postLength = [NSString stringWithFormat:@"%d", (int)[postData length]];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"http://shielded-forest-3008.herokuapp.com/user"]];
    [request setHTTPMethod:@"POST"];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPBody:postData];
    
    UIView * showActivity = [[UIView alloc]initWithFrame:CGRectMake(50, signUpOrigY + 40, 100, 100)];
    [self.view addSubview:showActivity];
    
    UIActivityIndicatorView * activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    activityIndicator.color = [UIColor orangeColor];
    activityIndicator.frame = showActivity.frame;
    
    [showActivity addSubview:activityIndicator];
    [activityIndicator startAnimating];
    
    NSLog(@"log click");
}

- (NSString *)urlEncodeValue:(NSString *)str
{
    NSString *result = (NSString *) CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)str, NULL, CFSTR("?=&+"), kCFStringEncodingUTF8));
    return result;
}

-(BOOL)prefersStatusBarHidden {return YES;}

@end
